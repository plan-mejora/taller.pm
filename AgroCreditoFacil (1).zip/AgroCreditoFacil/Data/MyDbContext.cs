using AgroCreditoFacil.Models;
using Microsoft.EntityFrameworkCore;

namespace AgroCreditoFacil.Data
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options) { }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Producto> Productos { get; set; }
        public DbSet<Carrito> Carritos { get; set; }
        public DbSet<CarritoProducto> CarritoProductos { get; set; }
        public object Producto { get; internal set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder){
            // Relación uno a muchos: Carrito -> CarritoProducto
            modelBuilder.Entity<CarritoProducto>()
                .HasOne(cp => cp.Carrito)
                .WithMany(c => c.Productos)
                .HasForeignKey(cp => cp.CarritoId);

            // Relación uno a uno: CarritoProducto -> Producto
            modelBuilder.Entity<CarritoProducto>()
                .HasOne(cp => cp.Producto)
                .WithMany() // Producto no tiene una referencia al carrito
                .HasForeignKey(cp => cp.ProductoId);
        }
    }
}