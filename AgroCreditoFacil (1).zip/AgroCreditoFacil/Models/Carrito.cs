using System.Collections.Generic;

namespace AgroCreditoFacil.Models
{
    public class Carrito
    {
        public int Id { get; set; } // Identificador único del carrito
        public int UsuarioId { get; set; } // Relación con el usuario
        public List<CarritoProducto> Productos { get; set; } // Relación con productos en el carrito
    }

    // Relación intermedia entre Carrito y Producto
    public class CarritoProducto
    {
        public int Id { get; set; } // Identificador único
        public int CarritoId { get; set; } // Relación con Carrito
        public Carrito Carrito { get; set; } // Propiedad de navegación
        public int ProductoId { get; set; } // Relación con Producto
        public Producto Producto { get; set; } // Propiedad de navegación
        public int Cantidad { get; set; } // Cantidad del producto en el carrito
    }
}
