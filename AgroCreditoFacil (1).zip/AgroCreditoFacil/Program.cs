using AgroCreditoFacil.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Habilitar sesiones
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Tiempo de expiración de la sesión
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Agregar servicios para MVC
builder.Services.AddControllersWithViews();

// Configuración de la base de datos
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
if (string.IsNullOrEmpty(connectionString))
{
    throw new InvalidOperationException("Conexion no encontrada");
}
builder.Services.AddDbContext<MyDbContext>(options =>
    options.UseMySQL(connectionString));

// Configuración de la autenticación
builder.Services.AddAuthentication("Cookies")
    .AddCookie(options =>
    {
        options.LoginPath = "/Usuario/IniciarSesion"; // Ruta para el inicio de sesión
        options.LogoutPath = "/Usuario/Logout"; // Ruta para cerrar sesión
    });

var app = builder.Build();

// Configuración de la sesión
app.UseSession();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
