using AgroCreditoFacil.Data;
using AgroCreditoFacil.Models;
using Microsoft.AspNetCore.Mvc;

namespace AgroCreditoFacil.Controllers
{
    public class ProductoController : Controller
    {
        private readonly MyDbContext _context;

        public ProductoController(MyDbContext context)
        {
            _context = context;
        }

        public IActionResult Menu()
        {
            var productos = _context.Productos.ToList();
            return View(productos);
        }

        [HttpGet]
        public IActionResult AgregarProducto()
        {
            var producto = new Producto();  // Crear un nuevo objeto Producto si es necesario
            return View(producto);  // Pasar el modelo a la vista
        }

        [HttpPost]
        public IActionResult AgregarProducto(Producto producto)
        {
            if (ModelState.IsValid)
            {
                _context.Productos.Add(producto);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(producto);  // Si el modelo no es válido, volver a la vista con el modelo
        }

        // Acción GET para editar un producto
        [HttpGet]
        public IActionResult EditarProducto(int id)
        {
            var producto = _context.Productos.Find(id);  // Obtén el producto de la base de datos
            if (producto == null)
            {
                return NotFound();  // Si el producto no existe, devuelve un error 404
            }
            return View(producto);  // Pasa el producto a la vista
        }

        // Acción POST para guardar los cambios del producto
        [HttpPost]
        public IActionResult EditarProducto(Producto producto)
        {
            if (ModelState.IsValid)
            {
                _context.Update(producto);  // Actualiza el producto en la base de datos
                _context.SaveChanges();
                return RedirectToAction("Index");  // Redirige a otra página después de guardar
            }
            return View(producto);  // Si el modelo no es válido, vuelve a la vista de edición
        }


        // Acción GET para eliminar un producto
        [HttpGet]
        public IActionResult EliminarProducto(int id)
        {
            var producto = _context.Productos.Find(id);  // Encuentra el producto por ID
            if (producto == null)
            {
                return NotFound();  // Si no se encuentra el producto, muestra un error
            }
            return View(producto);  // Pasa el producto a la vista
        }

        // Acción POST para confirmar la eliminación del producto
        [HttpPost]
        public IActionResult EliminarProducto(int id, Producto producto)
        {
            var productoExistente = _context.Productos.Find(id);
            if (productoExistente != null)
            {
                _context.Productos.Remove(productoExistente);
                _context.SaveChanges();
                return RedirectToAction("Index");  // Redirige a la lista de productos después de eliminar
            }
            return NotFound();
        }


    }
}