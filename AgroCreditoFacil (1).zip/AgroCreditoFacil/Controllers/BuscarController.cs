using AgroCreditoFacil.Data;
using AgroCreditoFacil.Models;
using Microsoft.AspNetCore.Mvc;


namespace AgroCreditoFacil.Controllers
{
    public class BuscarController : Controller
    {
        private readonly MyDbContext _context;

        public BuscarController(MyDbContext context)
        {
            _context = context;
        }

         // Método para realizar la búsqueda
        [HttpGet]
        public IActionResult Index1(string query)
        {
            if (string.IsNullOrEmpty(query))
            {
                return View("Resultados", new List<Producto>()); // Si no hay término de búsqueda, simplemente retorna la vista vacía
            }

            // Buscar productos cuyo nombre o descripción contenga el término de búsqueda
            var resultados = _context.Productos.Where(p => p.Nombre.Contains(query) || p.Descripcion.Contains(query)).ToList();

            return View("Resultados", resultados); // Retorna la vista con los productos encontrados
        }
    }
}
