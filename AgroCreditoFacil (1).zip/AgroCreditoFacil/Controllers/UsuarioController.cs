using AgroCreditoFacil.Data;
using AgroCreditoFacil.Models;
using Microsoft.AspNetCore.Mvc;

namespace AgroCreditoFacil.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly MyDbContext _context;
        public UsuarioController(MyDbContext context)
        {
            _context = context;
        }

        // Registro
        [HttpGet]
        public IActionResult Registro()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Registro(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                _context.Usuarios.Add(usuario);
                _context.SaveChanges();
                return RedirectToAction("IniciarSesion");
            }
            return View(usuario);
        }

        [HttpGet]
        public IActionResult IniciarSesion()
        {
            return View();
        }

        [HttpPost]
        public IActionResult IniciarSesion(string correo, string contraseña)
        {
            var usuario = _context.Usuarios.SingleOrDefault(u => u.Correo == correo && u.Contraseña == contraseña);
            if (usuario == null)
            {
                ModelState.AddModelError("", "Correo o contraseña incorrectos");
                return View();
            }

            // Guardar el nombre y el Id del usuario en la sesión
            HttpContext.Session.SetString("UsuarioNombre", usuario.Nombre);
            HttpContext.Session.SetInt32("UsuarioId", usuario.Id);

            return RedirectToAction("Menu", "Producto");
        }

        [HttpGet]
        public IActionResult CerrarSesion()
        {
            // Limpiar la sesión
            HttpContext.Session.Clear();
            return RedirectToAction("IniciarSesion");
        }

        [HttpGet]
        public IActionResult Perfil()
        {
            int? usuarioId = HttpContext.Session.GetInt32("UsuarioId");
            if (usuarioId == null)
            {
                return RedirectToAction("IniciarSesion");
            }

            var usuario = _context.Usuarios.Find(usuarioId);
            if (usuario == null)
            {
                return RedirectToAction("IniciarSesion");
            }

            return View(usuario);
        }


        [HttpGet]
        public IActionResult RecuperarContraseña()
        {
            return View();
        }
        [HttpPost]
        public IActionResult RecuperarContraseña(string correo)
        {
            var usuario = _context.Usuarios.SingleOrDefault(u => u.Correo == correo);
            if (usuario == null)
            {
                ModelState.AddModelError("", "Correo no registrado");
                return View();
            }
            // Generar una nueva contraseña temporal o link de recuperacion 
            usuario.Contraseña = "NuevaContraseñaTemporal123"; // "NuevaContraseñaTemporal
            _context.SaveChanges();

            // Aqui podrias enviar un correo con la nueva contraseña o link de recuperacion
            ViewBag.Mensaje = "Se ha enviado una nueva contraseña a tu correo";
            return View();
        }


        // Acción GET para cargar la vista de edición
        // Acción GET para cargar la vista de edición
        [HttpGet("editar-cuenta")]
        public IActionResult EditarCuenta()
        {
            int? usuarioId = HttpContext.Session.GetInt32("UsuarioId");
            if (usuarioId == null)
            {
                return RedirectToAction("IniciarSesion");
            }

            var usuario = _context.Usuarios.Find(usuarioId);
            if (usuario == null)
            {
                return RedirectToAction("IniciarSesion");
            }

            return View(usuario);
        }

        // Acción POST para guardar los cambios
        [HttpPost("editar-cuenta")]
        public IActionResult EditarCuenta(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                var usuarioExistente = _context.Usuarios.Find(usuario.Id);
                if (usuarioExistente == null)
                {
                    return NotFound();
                }

                // Actualizamos los datos
                usuarioExistente.Nombre = usuario.Nombre;
                usuarioExistente.Correo = usuario.Correo;
                usuarioExistente.Contraseña = usuario.Contraseña;

                _context.Usuarios.Update(usuarioExistente);
                _context.SaveChanges();

                return RedirectToAction("Perfil");
            }

            return View(usuario);
        }



        [HttpGet]
        public IActionResult EliminarCuenta(int id)
        {
            var usuario = _context.Usuarios.Find(id);
            if (usuario != null)
            {
                _context.Usuarios.Remove(usuario);
                _context.SaveChanges();
            }

            return RedirectToAction("Index", "Home");
        }
    }
}
