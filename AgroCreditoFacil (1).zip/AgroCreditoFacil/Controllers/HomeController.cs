using Microsoft.AspNetCore.Mvc;

namespace AgroCreditoFacil.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult QuienesSomos()
        {
            return View();
        }

        public IActionResult Novedades()
        {
            return View();
        }
    }

}


